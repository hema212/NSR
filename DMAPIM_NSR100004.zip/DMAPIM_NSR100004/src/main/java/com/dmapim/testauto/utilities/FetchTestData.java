package com.dmapim.testauto.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.ss.usermodel.DReadFromExcelataFormatter;
import org.apache.poi.ss.usermodel.DataFormatter;

public class FetchTestData {

	public static Object[][] ReadFromExcel(String TestDataLoc, String SheetName){
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(TestDataLoc);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Excel sheet file location get mentioned here
        HSSFWorkbook workbook = null;
		try {
			workbook = new HSSFWorkbook (fileInputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //get workbook 
        HSSFSheet worksheet=workbook.getSheet(SheetName);// get sheet from workbook
        HSSFRow Row=worksheet.getRow(0);     //get Row which starts from 0   
        
     
        int RowNum = worksheet.getPhysicalNumberOfRows();// count number of Rows
        int ColNum= Row.getLastCellNum(); // get last ColNum 
         
        Object Data[][]= new Object[RowNum-1][ColNum]; // pass count data in array
        String value = null;
        DataFormatter formatter = new DataFormatter();
            for(int i=0; i<RowNum-1; i++) //Loop work for Rows
            {  
                HSSFRow row= worksheet.getRow(i+1);
                 
                for (int j=0; j<ColNum; j++) //Loop work for colNum
                {
                    if(row==null)
                        Data[i][j]= "";
                    else
                    {
                        HSSFCell cell= row.getCell(j);
                        if(cell==null)
                            Data[i][j]= ""; //if it gets Null value it passes no data 
                        else
                        {
                            value = formatter.formatCellValue(cell);
                            Data[i][j]=value; 
                        }
                    }
                }
            }
			return Data;
	}
	
}
