package com.dmapim.testauto.driver;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.FileInputStream;
import java.io.IOException;



public class DriverScript {

	public WebDriver driver;
	public Properties prop;
	
	public WebDriver init_driver(String browserName, ChromeOptions options){
		if (browserName.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\hema_ramakrishna\\CoE\\Automaton\\drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
		}else if(browserName.equalsIgnoreCase("firefox")){
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\hema_ramakrishna\\CoE\\Automaton\\driversgeckodriver.exe");
			driver = new FirefoxDriver();
		}else{System.out.println("Error!");}
		return driver;
		
	}//init_driver
	
	public Properties init_properties(String properties) throws IOException{
		if (properties.equalsIgnoreCase("config")){
			prop = new Properties();
			FileInputStream ip = new FileInputStream("C:\\Users\\hema_ramakrishna\\Downloads\\NSR100004_v1\\NSR100004\\DMAPIM_NSR100004\\src\\main\\java\\com\\dmapim\\testauto\\properties\\config.properties");
			prop.load(ip);
		}
		if (properties.equalsIgnoreCase("objectrepo")){
			prop = new Properties();
			FileInputStream ip = new FileInputStream("C:\\Users\\hema_ramakrishna\\Downloads\\NSR100004_v1\\NSR100004\\DMAPIM_NSR100004\\src\\main\\java\\com\\dmapim\\testauto\\properties\\object_repo.properties");
			prop.load(ip);
		}
		
		return prop;
	}//init_properties
	
	
	
	
	
	
	
}
