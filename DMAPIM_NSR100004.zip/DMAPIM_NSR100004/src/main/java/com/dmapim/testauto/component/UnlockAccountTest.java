package com.dmapim.testauto.component;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.dmapim.testauto.driver.DriverScript;
import com.dmapim.testauto.utilities.FetchTestData;
import com.dmapim.testauto.utilities.SQLJDBCDriver;

public class UnlockAccountTest {

	WebDriver driver;
	String SSFilename = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss'.jpg'").format(new Date());
	String TC_ID = null;
	public DriverScript driversetup;
	public Properties configProp;
	public Properties objectRepo;
	ChromeOptions options;
	String TC_ID_Temp = null;
	
	@BeforeClass
	public void Properties() throws IOException{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hema_ramakrishna\\CoE\\Automaton\\drivers\\chromedriver.exe");
	driversetup = new DriverScript();	
	configProp = driversetup.init_properties("config");
	objectRepo = driversetup.init_properties("objectrepo");
	}
	
	@BeforeMethod
	public void driverConfig(){
		if(configProp.getProperty("headless").equalsIgnoreCase("yes")){
			ChromeOptions options = new ChromeOptions();
			//options.addArguments("--disable-gpu");
			options.addArguments("--headless");
			options.addArguments("disable-notifications");
			driver = driversetup.init_driver(configProp.getProperty("browser"), options);
		}else if(configProp.getProperty("headless").equalsIgnoreCase("no")){
			ChromeOptions options = new ChromeOptions();
			options.addArguments("start-maximized");
			options.addArguments("start-fullscreen");
			options.addArguments("disable-infobars");
			options.addArguments("disable-notifications");
			driver = driversetup.init_driver(configProp.getProperty("browser"), options);
		}
	}	
		
		@Test (enabled = true, dataProvider = "TestDataForgotPassword")
		public void ForgotPWTest(String TestCaseID, String username, String NewPassword, String UserEmailID, String Expected, String TestType) throws ClassNotFoundException, SQLException, InterruptedException, IOException
		{

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			//User Details
			//String username = "DemoUser1";
			//String UserContact = "1236661236";
			//String UserEmailID = "demo@thbs.com";
			//String NewPassword = "Password123!";
			//String apphost = objectRepo.getProperty("apphost");//objectRepo.getProperty("apphost");
			String apphost = "34.227.233.177";
			
			//login to pub portal
			driver.get(configProp.getProperty("pub_url_34"));
			//http://15.206.44.116/dmapim/publisher/login.html?publisherName=smitha
			//http://34.227.233.177/dmapim/pubportal/four
			
			//login to pub portal
			driver.get("http://34.227.233.177/dmapim/publisher/login.html?publisherName=four");
			//http://15.206.44.116/dmapim/publisher/login.html?publisherName=smitha
			//http://34.227.233.177/dmapim/pubportal/four
			for(int i=1;i<=4;i++){
			driver.findElement(By.cssSelector("#username_view")).sendKeys(username);
			driver.findElement(By.cssSelector("#password")).sendKeys(RandomStringUtils.randomAlphabetic(10));
			driver.findElement(By.cssSelector("#container > div > center > form > div > div:nth-child(4) > div > button")).click();
			Thread.sleep(1000);}
			//correct cred login
			driver.findElement(By.cssSelector("#username_view")).sendKeys(username);
			driver.findElement(By.cssSelector("#password")).sendKeys("Password123!");
			driver.findElement(By.cssSelector("#container > div > center > form > div > div:nth-child(4) > div > button")).click();
			Thread.sleep(2000);
			
			driver.findElement(By.id("otherLoginOptions")).click();
			Actions action = new Actions(driver);
			action.moveToElement(driver.findElement(By.xpath("/html/body/div[2]/div[2]/a"))).click().build().perform();
			driver.findElement(By.xpath("//*[@id=\"username_view\"]")).sendKeys(username);
			driver.findElement(By.xpath("//*[@id=\"container\"]/div/center/div/div/div[4]/div[1]/button")).click();
			driver.findElement(By.xpath("//*[@id=\"closeModal\"]")).click();
			//driver.close();
			
			String ResetURL = null;
			try {
				ResetURL = SQLJDBCDriver.getDB("jdbc:mysql://3.217.111.247:3306/NSR4FALSE", "root", "Thbs123!", apphost, "four", "pub", "unlock");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Redirecting to... "+ResetURL);
			Thread.sleep(2000);
			driver.get(ResetURL);
			
			driver.findElement(By.cssSelector("#username_view")).sendKeys(username);
			//driver.findElement(By.id("contact_number")).sendKeys(UserContact);		//for 34 machine
			driver.findElement(By.cssSelector("#email_id")).sendKeys(UserEmailID);
			//driver.findElement(By.cssSelector("#newPassword")).sendKeys("Password123!");
			//driver.findElement(By.cssSelector("#confirmPassword")).sendKeys("Password123!");		
			driver.findElement(By.cssSelector("#loginbutton")).click();
			
			Thread.sleep(5000);
			
			boolean invalidpwdheader = driver.findElement(By.cssSelector("#errorBlock > div")).getText().contains("Please enter valid inputs");
			if(!invalidpwdheader == true)
			{
			//validate login with new credential
			driver.findElement(By.id("username_view")).sendKeys(username);
			driver.findElement(By.id("password")).sendKeys(NewPassword);
			driver.findElement(By.xpath("//*[@id=\"container\"]/div/center/form/div/div[4]/div/button")).click();
			Thread.sleep(2000);}
			
			if(TestType.equalsIgnoreCase("P")){
				Assert.assertEquals(driver.getCurrentUrl(), Expected);
				System.out.println("Testcase "+TestCaseID+" Passed!");
			}
			else{
				System.out.println("Testcase "+TestCaseID+" Failed!");
			}
			
			//Screenshot
			//String SSFilename = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss'.jpg'").format(new Date());
			File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshotFile, new File("C:\\Users\\sourav_sen\\DMAPIM\\DMAPIM_NSR100004\\ScreenCapture\\NSR100004\\Passed Test Scenarios\\UnlockAccountTest\\DMAPIM_NSR100004_"+TestCaseID+"_"+SSFilename));
			System.out.println("Passed Scenario: Screenshot captured.");
			
			Thread.sleep(2000);
			}

	
		@AfterMethod(enabled = false)
		public void teardownmethod(){
			driver.close();
			driver.quit();
		}
		
		@AfterMethod (enabled = true)
		public void teardown(ITestResult result){
			if(ITestResult.FAILURE==result.getStatus()){
				try{
					TakesScreenshot screenshot=(TakesScreenshot)driver;
					File src=screenshot.getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(src, new File("C:\\Users\\sourav_sen\\DMAPIM\\DMAPIM_NSR100004\\ScreenCapture\\NSR100004\\Failed Test Scenarios\\UnlockAccountTest\\DMAPIM_NSR100004_Failed_"+TC_ID_Temp+"_"+SSFilename));				
					System.out.println("Failed Scenario: Screenshot Captured.");
				}catch (Exception e){
					System.out.println("Exception while taking screenshot "+e.getMessage());
				} 
		}
			TC_ID_Temp = null;
			driver.close();
			driver.quit();
		}
	
		@DataProvider(name="TestDataForgotPassword")
	    public static Object[][] ReadFromExcel() throws IOException
	    {
		        return FetchTestData.ReadFromExcel("C:\\Users\\sourav_sen\\DMAPIM\\DMAPIM_NSR100004\\src\\main\\java\\com\\dmapim\\testauto\\scenarios\\DMAPIM_NSR100004_TestData_v2.xls","UnlockAccount");
		    }
	
	
}
