package com.dmapim.testauto.component;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.dmapim.testauto.driver.DriverScript;
import com.dmapim.testauto.utilities.FetchTestData;

public class LoginTest {//class

		WebDriver driver;
		String SSFilename = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss'.jpg'").format(new Date());
		String TC_ID = null;
		public DriverScript driversetup;
		public Properties configProp;
		public Properties objectRepo;
		ChromeOptions options;
		String TC_ID_Temp = null;
		
		@BeforeClass
		public void Properties() throws IOException{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\hema_ramakrishna\\CoE\\Automaton\\drivers\\chromedriver.exe");
		driversetup = new DriverScript();	
		configProp = driversetup.init_properties("config");
		objectRepo = driversetup.init_properties("objectrepo");
		}
		
		@BeforeMethod
		public void driverConfig(){
			if(configProp.getProperty("headless").equalsIgnoreCase("yes")){
				ChromeOptions options = new ChromeOptions();
				//options.addArguments("--disable-gpu");
				options.addArguments("--headless");
				options.addArguments("disable-notifications");
				driver = driversetup.init_driver(configProp.getProperty("browser"), options);
			}else if(configProp.getProperty("headless").equalsIgnoreCase("no")){
				ChromeOptions options = new ChromeOptions();
				options.addArguments("start-maximized");
				options.addArguments("start-fullscreen");
				options.addArguments("disable-infobars");
				options.addArguments("disable-notifications");
				driver = driversetup.init_driver(configProp.getProperty("browser"), options);
			}
		}
		
		
		@Test(enabled = true, dataProvider="TestData2")
		public void DMAPIM_Login(String TestCaseID, String Username, String Password, String Expected, String TestType) throws InterruptedException, IOException{
			
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			TC_ID_Temp = TestCaseID;
			try{		
			//Test Steps
			driver.get(configProp.getProperty("pub_url_34"));
			//http://15.206.44.116/dmapim/publisher/login.html?publisherName=smitha
			//http://34.227.233.177/dmapim/publisher/login.html?publisherName=four
			driver.findElement(By.id(objectRepo.getProperty("LoginUsername"))).sendKeys(Username);
			driver.findElement(By.id(objectRepo.getProperty("LoginPassword"))).sendKeys(Password);
			driver.findElement(By.xpath(objectRepo.getProperty("LoginButton"))).click();
			}catch(Exception e){
			}
			
			Thread.sleep(1000);
			if(TestType.equalsIgnoreCase("P")){
				Assert.assertEquals(driver.getCurrentUrl(), Expected);
			}
			if(TestType.equalsIgnoreCase("N")){
				Assert.assertEquals(driver.findElement(By.cssSelector("#errorBlock > div") ).getText(), Expected);
			}

			//Screenshot
			//String SSFilename = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss'.jpg'").format(new Date());
			File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshotFile, new File("C:\\Users\\hema_ramakrishna\\Downloads\\NSR100004_v1\\NSR100004\\DMAPIM_NSR100004\\ScreenCapture\\NSR100004\\Passed Test Scenarios\\LoginTest\\DMAPIM_NSR100004_"+TestCaseID+"_"+SSFilename));
			System.out.println("Passed Scenario: Screenshot captured.");
			//http://34.227.233.177/dmapim/publisher/login.html?publisherName=sa
			//C:\\Users\\sourav_sen\\Desktop\\AutomateEverything!\\TestBed\\Test Evidence\\NSR100004\\Passed Test Scenarios\\DMAPIM_NSR100004_
		}
		
		
		@AfterMethod(enabled = false)
		public void teardownmethod(){
			driver.close();
			driver.quit();

		}
		
		@AfterMethod (enabled = true)
		public void teardown(ITestResult result){
			if(ITestResult.FAILURE==result.getStatus()){
				try{
					TakesScreenshot screenshot=(TakesScreenshot)driver;
					File src=screenshot.getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(src, new File("C:\\Users\\hema_ramakrishna\\Downloads\\NSR100004_v1\\NSR100004\\DMAPIM_NSR100004\\ScreenCapture\\NSR100004\\Failed Test Scenarios\\LoginTest\\DMAPIM_NSR100004_Failed_"+TC_ID_Temp+"_"+SSFilename));				
					System.out.println("Failed Scenario: Screenshot Captured.");
				}catch (Exception e){
					System.out.println("Exception while taking screenshot "+e.getMessage());
				} 
		}
			TC_ID_Temp = null;
			driver.close();
			driver.quit();
		}
		
		@DataProvider(name="TestData2")
	    public static Object[][] ReadFromExcel() throws IOException{
	        return FetchTestData.ReadFromExcel("C:\\Users\\hema_ramakrishna\\Downloads\\NSR100004_v1\\NSR100004\\DMAPIM_NSR100004\\src\\main\\java\\com\\dmapim\\testauto\\scenarios\\DMAPIM_NSR100004_TestData_v2.xls","Login");
	    }

}// end of class		


