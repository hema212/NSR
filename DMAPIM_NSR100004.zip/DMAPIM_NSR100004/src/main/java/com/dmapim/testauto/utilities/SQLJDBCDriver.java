package com.dmapim.testauto.utilities;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SQLJDBCDriver {

	public static void main(String a[]) throws ClassNotFoundException, SQLException, IOException{
		
		String Dburl, dbUsername, dbPassword, domain, loginType, apphost;
		Dburl = "jdbc:mysql://3.217.111.247:3306/dmapim_v211_R";
		//jdbc:mysql://3.217.111.247:3306/dmapim_v211_R, jdbc:mysql://15.206.44.116:3306/dmapim_v211_4
		dbUsername = "root";
		dbPassword = "Thbs123!";
		apphost = "34.227.233.177";
		domain = "four";
		loginType = "pub";
		System.out.println(getDB(Dburl, dbUsername, dbPassword, apphost, domain, loginType));
		//apphost = 34.227.233.177, 15.206.44.116
		//loginType = pub/devDefined/devCommon
		//for 34 machine, pubName is four, myportal is for 15 machine
		//File DBLink = new File(System.getProperty("user.home"), "Desktop");
		
		/*
		String SSFilename = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
		File DBLink = new File(System.getProperty("user.home"), "Desktop\\UNLOCKLinkLogs_FOUR_DOMAIN.txt");
		FileWriter fw = new FileWriter(DBLink);
		fw.write(getDB(Dburl, dbUsername, dbPassword, apphost, domain, loginType));
		fw.close();*/
	
		//System.out.println(DBLink.getPath());
        //java.awt.Desktop.getDesktop().open(DBLink);
		
		
	}
	
	public static String getDB(String Dburl, String dbUsername, String dbPassword, String apphost, String pubName, String loginType) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String temp = null;
		String resetURL = null;
		ResultSet resultset = null;
		String contextportal = null;
		Connection connect = DriverManager.getConnection(Dburl, dbUsername, dbPassword);
		Statement statement = connect.createStatement();
		if(loginType == "pub"){contextportal="pubportal";} else if(loginType == "devDefined") {contextportal="devportal";} else{contextportal="devportal";}
		if(apphost == "15.206.44.116"){
		resultset = statement.executeQuery("SELECT * FROM dmapim_v211_4.user_reset_token WHERE expiry=(SELECT max(expiry) FROM dmapim_v211_4.user_reset_token where type = '"+RecoveryType+"');");
		}
		if(apphost == "34.227.233.177"){
		resultset = statement.executeQuery("SELECT * FROM NSR4FALSE.user_reset_token WHERE expiry=(SELECT max(expiry) FROM NSR4FALSE.user_reset_token where type = '"+RecoveryType+"');");	
		}
		
		
		//SELECT * FROM dmapim_v211_R.user_reset_token WHERE expiry=(SELECT max(expiry) FROM dmapim_v211_R.user_reset_token where type = 'forgot');		
		//"select user_reset_token_id, token from dmapim_v211_R.sub_organization so join dmapim_v211_R.user usr on so.suborg_id=usr.suborg_id join dmapim_v211_R.user_reset_token urt on usr.user_id=urt.user_id	;");
		//System.out.println(resultset);
		//"select user_reset_token_id, token from dmapim_v211_4.sub_organization so join dmapim_v211_4.user usr on so.suborg_id=usr.suborg_id join dmapim_v211_4.user_reset_token urt on usr.user_id=urt.user_id;");
		while(resultset.next())  
		//System.out.println(res.getInt(1)+"  "+res.getString(2)+"  "+res.getString(3)....);  
		temp = resultset.getString(3);
		connect.close();
		resetURL = "http://"+apphost+"/dmapim/"+contextportal+"/"+pubName+"/"+temp+"?loginType="+loginType;
		return resetURL;
		
		//<APPLICATION_HOST_NAME>/<contextPath>/pubportal/<publisherName>/token?loginType=pub
		//
		
	}
	
	
}
