package com.dmapim.testauto.component;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.openqa.selenium.JavascriptExecutor;

public class IntegrationTest {

	
	WebDriver driver=null;
	String CaseSensitive;//used for test flow change
	JavascriptExecutor Scrool = (JavascriptExecutor) driver;//for page scroll
	//EventFiringWebDriver evt = new EventFiringWebDriver(driver);//for inside window scroll
	
	@BeforeClass
	public void Properties(){
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hema_ramakrishna\\CoE\\Automaton\\drivers\\chromedriver.exe");
	}
	
	@BeforeSuite
	public void URLConfig(){
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		options.addArguments("start-fullscreen");
		options.addArguments("disable-notifications");
		
	}
	
	@Test(enabled = false)
	public void Login(String username, String password){
		JavascriptExecutor Scrool = (JavascriptExecutor) driver;//for page scroll
		EventFiringWebDriver evt = new EventFiringWebDriver(driver);//for inside window scroll
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		options.addArguments("start-fullscreen");
		driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Login to Pub
		driver.get("http://34.227.233.177/dmapim/publisher/login.html?publisherName=five");//domain = two/four
		//http://15.206.44.116/dmapim/publisher/login.html?publisherName=smitha
		driver.findElement(By.id("username_view")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/center/form/div/div[4]/div/button")).click();
	}
	
	
	@Test(enabled = false)
	public void CreateBackEnd() throws InterruptedException{
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[1]/a/span")).click();
		driver.findElement(By.xpath("//*[@id=\"addAPIButton\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"newBackendEPName\"]")).sendKeys("TestBackend");
		//driver.findElement(By.xpath("//*[@id=\"addBackendEndPointForm\"]/div[3]/div[2]/div[2]")).click();
		Thread.sleep(1000);
		//PROD BACKEND TYPE SELECT
		//driver.findElement(By.xpath("//div[@class='ui dropdown dropdownWidth backendEPTypeVal add selection']")).click();
		driver.findElement(By.xpath("//div[@class='ui dropdown dropdownWidth backendEPTypeVal add selection']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Production')]")).click();	
		//driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Production')]"));
		//new Actions(driver).moveToElement(driver.findElement(By.xpath("//div[contains(text(), 'Production')]"))).click().build().perform();
		Thread.sleep(1000);	
		driver.findElement(By.cssSelector("#newBackendEPIp")).sendKeys("10.23.666.184");
		driver.findElement(By.cssSelector("#newBackendEPPort")).sendKeys("9091");
		driver.findElement(By.cssSelector("#newBackendEPDesc")).sendKeys("Something");
		Thread.sleep(1000);
		//((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");	
		EventFiringWebDriver evt = new EventFiringWebDriver(driver);//for inside window scroll
		evt.executeScript("document.querySelector('#addBackendEndPointModal > div.content.contentpositioning').scrollTop=500");
		driver.findElement(By.cssSelector("#submitEndPoint")).click();
		//Delay
		Thread.sleep(3000);
	}
	
	
	@Test(enabled = false)
	public void CreateGateway() throws InterruptedException{
		//Gateway Creation
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[4]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"addAPIButton\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"newGatewayName\"]")).sendKeys("TestGateway");
		Thread.sleep(2000);
		//gatewayType
		driver.findElement(By.xpath("//*[@id=\"addGatewayform\"]/div[2]/div[1]")).click();
		Thread.sleep(2000);
		//new Actions(driver).moveToElement(driver.findElement(By.xpath("//div[contains(text(), 'Production')]"))).click().build().perform();
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Production')]")).click();
		//
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#newIp")).sendKeys("10.666.66.66");
		driver.findElement(By.cssSelector("#newPort")).sendKeys("8080");
		driver.findElement(By.cssSelector("#newDesc")).sendKeys("TestGateway");
		driver.findElement(By.cssSelector("#submitGateway")).click();
		Thread.sleep(2000);
	}
	
	@Test(enabled = false)
	public void CreateUsagePolicy() throws InterruptedException{
		//Usage Policy
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[5]/a/span")).click();
		driver.findElement(By.cssSelector("#addUsagePolicyButton")).click();
		driver.findElement(By.cssSelector("#newUsagePolicyName")).sendKeys("TestPolicy_Request Count Limit");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='ui dropdown dropdownWidth selection']")).click();
		Thread.sleep(2000);
		//Request Count Limit
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Request count limit')]")).click();
		//driver.findElement(By.id("submitNewPolicy")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#submitNewPolicy")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#numberOfRequests")).sendKeys("400");
		driver.findElement(By.cssSelector("#btnSubmit")).click();
		driver.findElement(By.xpath("//*[@id=\"settingIcon\"]/span/i")).click();
		driver.findElement(By.cssSelector("#subForApprl")).click();
		Thread.sleep(1000);
	}
	
	@Test(enabled = false)
	public void CreateAPI() throws InterruptedException{
		//Create REST API
		driver.findElement(By.xpath("//span[contains(text(), 'APIs')]")).click();
		driver.findElement(By.id("addAPIButton")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='newAPIName']")).sendKeys("TestAPI");
		driver.findElement(By.xpath("//input[@id='newAPIShortDesc']")).sendKeys("TestAPI");
		driver.findElement(By.xpath("//div[@id='submitNewAPI']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"detDesc\"]")).sendKeys("TestAPI");
		Thread.sleep(1000);
		Scrool.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#submitOverview")).click();
		Thread.sleep(1000);
		//Resources Tab
		driver.findElement(By.cssSelector("#resourceTab")).click();
		driver.findElement(By.cssSelector("#resourcesbtn > div")).click();
		driver.findElement(By.xpath("//*[@id=\"newResourceName\"]")).sendKeys("/TestResource");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"addResourceForm\"]/div[2]/div[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'GET')]")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#newResourceDesc")).sendKeys("TestResource");
		driver.findElement(By.cssSelector("#submitNewApiResource")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#rescexposureep")).sendKeys("/TestBP");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#submitResource")).click();
		Thread.sleep(1000);
		//Endpoints tab
		driver.findElement(By.cssSelector("#endpointsTab")).click();
		driver.findElement(By.xpath("//*[@id=\"divProdEndPoint\"]/div[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'TestBackend')]")).click();
		Thread.sleep(1000);
		Scrool.executeScript("window.scrollBy(0,150)", "");
		driver.findElement(By.cssSelector("#apiVersionBackendEndPointsProdBasepath")).sendKeys("/BP");
		Thread.sleep(1000);
		Scrool.executeScript("window.scrollBy(0,350)", "");
		driver.findElement(By.cssSelector("#submitVersionBackendEndPoint")).click();
		Thread.sleep(3000);
		//approving api
		driver.findElement(By.xpath("//*[@id=\"settingIcon\"]/i")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"subForApprl\"]")).click();
		Thread.sleep(2000);
	}
	
	@Test(enabled = false)
	public void CreateAPIPack() throws InterruptedException{
		//Create an API Pack
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[3]/a/span")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#addAPIPackButton")).click();
		driver.findElement(By.xpath("//input[@id='newAPIPackName']")).sendKeys("TestPack8");
		driver.findElement(By.xpath("//input[@id='newAPIPackShortDesc']")).sendKeys("TestPack");
		Thread.sleep(1000);
		//driver.findElement(By.xpath("//div[@id='submitNewAPIPack']")).click();
		driver.findElement(By.cssSelector("#submitNewAPIPack")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#detDesc")).sendKeys("TestPack");
		Scrool.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#savePackOverview")).click();
		//driver.switchTo().alert().accept();	

		Thread.sleep(3000);
		//Pack Content Tab
		driver.findElement(By.cssSelector("#packcontentTab")).click();
		driver.findElement(By.cssSelector("#btnNewResToPck")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form1\"]/div[1]/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'TestAPI')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("chk_9c040100580032c7")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#btnAddResToPck")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#savePackResource")).click();
		//Usage Tab
		driver.findElement(By.cssSelector("#usagetab")).click();
		driver.findElement(By.cssSelector("#btnAddPlan")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#newplnname")).sendKeys("TestPlan");
		driver.findElement(By.cssSelector("#submitNewPlan")).click();
		Thread.sleep(2000);
		//Branding Tab
		driver.findElement(By.cssSelector("#brandingTab")).click();
		Scrool.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"selCat\"]")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(".jqtree-title.jqtree_common.showMode")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("submitCategory")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("saveBrandingDetails")).click();
		driver.findElement(By.cssSelector("#saveBrandingDetails")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#usagetab")).click();
		driver.findElement(By.cssSelector("#plan_9c04010058000247")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"res_plan_9c04010058000247\"]/span")).click();
		driver.findElement(By.cssSelector("#usagePlanChkboxAll")).click();
		driver.findElement(By.cssSelector("#savePlanRescBtn")).click();
		driver.findElement(By.xpath("//*[@id=\"pri_plan_9c04010058000247\"]/span")).click();
		Scrool.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#usage_to")).sendKeys("600");
		driver.findElement(By.cssSelector("#savePricingBtn")).click();
		//Approve Plan
		driver.findElement(By.xpath("//*[@id=\"planSettingIcon\"]")).click();
		driver.findElement(By.cssSelector("#subPlnApproval")).click();
		Thread.sleep(5000);
	}
	
	@Test(enabled = false)
	public void SyncMod() throws InterruptedException{
		//gateway syncing
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[8]/a/span")).click();
		driver.findElement(By.xpath("//span[contains(text(), ' Changes ')]")).click();
		Thread.sleep(4000);
		WebElement contentVisible = driver.findElement(By.id("selectAllArti"));
        //System.out.println(contentVisible.isDisplayed());
        if(contentVisible.isDisplayed() == false) {
        	String getNoartifactMessage = driver.findElement(By.id("noGridData")).getText();
            System.out.println(getNoartifactMessage);
        }
        else if(contentVisible.isDisplayed() == true) {
        	driver.findElement(By.id("selectAllArti")).click();
		    driver.findElement(By.id("addPropagationButton")).click();
		    Thread.sleep(2000);
		    evt.executeScript("document.querySelector('#syncArtifactsModal > div.content.contentpositioning').scrollTop=800");
		    Thread.sleep(2000);
		    driver.findElement(By.cssSelector("#syncArtifacts")).click();
		    Thread.sleep(3000);
			for (int k=0; k<3; k++) {
				driver.findElement(By.id("syncArtifacts")).click();
    		    Thread.sleep(2000);
			}
		}Thread.sleep(2000);
	}
	
	
	
	
	@Test(enabled = true, dataProvider = "TestData3")
	public void E2ETest(String username, String password) throws InterruptedException{
		//PARAMETERIZE EVERYTHING
		
		//Config
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		options.addArguments("start-fullscreen");
		options.addArguments("disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor Scrool = (JavascriptExecutor) driver;//for page scroll
		EventFiringWebDriver evt = new EventFiringWebDriver(driver);//for inside window scroll
		
		//Login to Pub
		driver.get("http://34.227.233.177/dmapim/publisher/login.html?publisherName=five");//domain = two/four
		//http://15.206.44.116/dmapim/publisher/login.html?publisherName=smitha
		driver.findElement(By.id("username_view")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/center/form/div/div[4]/div/button")).click();

		
		//Backend
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[1]/a/span")).click();
		driver.findElement(By.xpath("//*[@id=\"addAPIButton\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"newBackendEPName\"]")).sendKeys("TestBackend");
		//driver.findElement(By.xpath("//*[@id=\"addBackendEndPointForm\"]/div[3]/div[2]/div[2]")).click();
		Thread.sleep(1000);
		//PROD BACKEND TYPE SELECT
		//driver.findElement(By.xpath("//div[@class='ui dropdown dropdownWidth backendEPTypeVal add selection']")).click();
		driver.findElement(By.xpath("//div[@class='ui dropdown dropdownWidth backendEPTypeVal add selection']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Production')]")).click();	
		//driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Production')]"));
		//new Actions(driver).moveToElement(driver.findElement(By.xpath("//div[contains(text(), 'Production')]"))).click().build().perform();
		Thread.sleep(2000);	
		//driver.switchTo().alert().dismiss();
		driver.findElement(By.cssSelector("#newBackendEPIp")).sendKeys("10.23.666.184");
		driver.findElement(By.cssSelector("#newBackendEPPort")).sendKeys("9091");
		driver.findElement(By.cssSelector("#newBackendEPDesc")).sendKeys("Something");
		Thread.sleep(1000);
		//((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");	
		evt.executeScript("document.querySelector('#addBackendEndPointModal > div.content.contentpositioning').scrollTop=500");
		driver.findElement(By.cssSelector("#submitEndPoint")).click();
		//Delay
		Thread.sleep(3000);
		
		
		//Gateway
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[4]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"addAPIButton\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"newGatewayName\"]")).sendKeys("TestGateway");
		Thread.sleep(2000);
		//gatewayType
		driver.findElement(By.xpath("//*[@id=\"addGatewayform\"]/div[2]/div[1]")).click();
		Thread.sleep(2000);
		//new Actions(driver).moveToElement(driver.findElement(By.xpath("//div[contains(text(), 'Production')]"))).click().build().perform();
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Production')]")).click();
		//
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#newIp")).sendKeys("10.666.66.66");
		driver.findElement(By.cssSelector("#newPort")).sendKeys("8080");
		driver.findElement(By.cssSelector("#newDesc")).sendKeys("TestGateway");
		driver.findElement(By.cssSelector("#submitGateway")).click();
		Thread.sleep(2000); 
		
		//gateway sync
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[8]/a/span")).click();
		driver.findElement(By.xpath("//span[contains(text(), ' Changes ')]")).click();
		Thread.sleep(4000);
		WebElement contentVisible = driver.findElement(By.id("selectAllArti"));
        //System.out.println(contentVisible.isDisplayed());
        if(contentVisible.isDisplayed() == false) {
        	String getNoartifactMessage = driver.findElement(By.id("noGridData")).getText();
            System.out.println(getNoartifactMessage);
        }
        else if(contentVisible.isDisplayed() == true) {
        	driver.findElement(By.id("selectAllArti")).click();
		    driver.findElement(By.id("addPropagationButton")).click();
		    Thread.sleep(2000);
		    evt.executeScript("document.querySelector('#syncArtifactsModal > div.content.contentpositioning').scrollTop=800");
		    Thread.sleep(2000);
		    driver.findElement(By.cssSelector("#syncArtifacts")).click();
		    Thread.sleep(3000);
			for (int k=0; k<3; k++) {
				driver.findElement(By.id("syncArtifacts")).click();
    		    Thread.sleep(2000);
			}
		}Thread.sleep(2000);
		
		
		//API
		driver.findElement(By.xpath("//span[contains(text(), 'APIs')]")).click();
		driver.findElement(By.id("addAPIButton")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='newAPIName']")).sendKeys("TestAPI");
		driver.findElement(By.xpath("//input[@id='newAPIShortDesc']")).sendKeys("TestAPI");
		driver.findElement(By.xpath("//div[@id='submitNewAPI']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"detDesc\"]")).sendKeys("TestAPI");
		Thread.sleep(1000);
		Scrool.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#submitOverview")).click();
		Thread.sleep(1000);
		//Resources Tab
		driver.findElement(By.cssSelector("#resourceTab")).click();
		driver.findElement(By.cssSelector("#resourcesbtn > div")).click();
		driver.findElement(By.xpath("//*[@id=\"newResourceName\"]")).sendKeys("/TestResource");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"addResourceForm\"]/div[2]/div[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'GET')]")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#newResourceDesc")).sendKeys("TestResource");
		driver.findElement(By.cssSelector("#submitNewApiResource")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#rescexposureep")).sendKeys("/TestBP");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("#submitResource")).click();
		Thread.sleep(1000);
		//Endpoints tab
		driver.findElement(By.cssSelector("#endpointsTab")).click();
		driver.findElement(By.xpath("//*[@id=\"divProdEndPoint\"]/div[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'TestBackend')]")).click();
		Thread.sleep(1000);
		Scrool.executeScript("window.scrollBy(0,150)", "");
		driver.findElement(By.cssSelector("#apiVersionBackendEndPointsProdBasepath")).sendKeys("/BP");
		Thread.sleep(1000);
		Scrool.executeScript("window.scrollBy(0,350)", "");
		driver.findElement(By.cssSelector("#submitVersionBackendEndPoint")).click();
		Thread.sleep(3000);
		//approving api
		driver.findElement(By.xpath("//*[@id=\"settingIcon\"]/i")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"subForApprl\"]")).click();
		Thread.sleep(2000);
		
		
		
		
		
		
		
		
		
		//Scroller
		

		//Gateway Sync
		/*
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[8]/a/span")).click();
		driver.findElement(By.xpath("//span[contains(text(), ' Changes ')]")).click();
		Thread.sleep(4000);
		WebElement contentVisible = driver.findElement(By.id("selectAllArti"));
        //System.out.println(contentVisible.isDisplayed());
        if(contentVisible.isDisplayed() == false) {
        	String getNoartifactMessage = driver.findElement(By.id("noGridData")).getText();
            System.out.println(getNoartifactMessage);
        }
        else if(contentVisible.isDisplayed() == true) {
        	driver.findElement(By.id("selectAllArti")).click();
		    driver.findElement(By.id("addPropagationButton")).click();
		    Thread.sleep(2000);
		    evt.executeScript("document.querySelector('#syncArtifactsModal > div.content.contentpositioning').scrollTop=800");
		    Thread.sleep(2000);
		    driver.findElement(By.cssSelector("#syncArtifacts")).click();
		    Thread.sleep(3000);
		    /*
			for (int k=0; k<3; k++) {
				driver.findElement(By.id("syncArtifacts")).click();
    		    Thread.sleep(2000);
			}
		}Thread.sleep(2000);*/
		/*
		String type = "GAUPP";
		driver.findElement(By.xpath("//*[@id=\"menuAccordion\"]/div[8]/a/span")).click();
		driver.findElement(By.xpath("//span[contains(text(), ' Changes ')]")).click();
		Thread.sleep(4000);
		if(type.equalsIgnoreCase("Backend")){
			driver.findElement(By.xpath("//div[@class='title']/div[contains(text(), 'Changes to Backend Endpoint')]")).click();
		}
		if(type.equalsIgnoreCase("GAUPP")){
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[contains(text(),'golf_1.0(REST)')]/following-sibling::input[@type='checkbox']")).click();	
			Thread.sleep(2000);
		}
		if(type.equalsIgnoreCase("Subs")){
			
		}
		else System.out.println("Error in Sync!");*/
		

		
	}
	
	
	@DataProvider(name = "TestData3")
	public Object[][] LoginTestData(){
		Object[][] data = new Object[1][2];
		data[0][0] = "admin";
		data[0][1] = "Password123!";
		/*
		data[1][0] = "admin";
		data[1][1] = "12345";*/
		return data;
	}
	
	
	@AfterMethod(enabled = true)
	public void teardown(ITestResult result){
		/*
		String SSFilename = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss'.jpg'").format(new Date());
		File screenshotFile1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile1, new File("C:\\Users\\sourav_sen\\Desktop\\AutomateEverything!\\TestBed\\Test Evidence\\NSR100004\\Failed Test Scenarios\\DMAPIM_NSR100004_Failed"+TestCaseID+"_"+SSFilename));
		 */		
		//using ITestResult.FAILURE is equals to result.getStatus then it enter into if condition
		if(ITestResult.FAILURE==result.getStatus()){
			try{

				// To create reference of TakesScreenshot
				TakesScreenshot screenshot=(TakesScreenshot)driver;
				// Call method to capture screenshot
				File src=screenshot.getScreenshotAs(OutputType.FILE);
				// Copy files to specific location 
				// result.getName() will return name of test case so that screenshot name will be same as test case name
				FileUtils.copyFile(src, new File("C:\\Users\\sourav_sen\\Desktop\\AutomateEverything!\\TestBed\\Test Evidence\\NSR100004\\Failed Test Scenarios\\DMAPIM_NSR100004_Failed.jpg"));				

				System.out.println("Successfully captured a screenshot");
			}catch (Exception e){
				System.out.println("Exception while taking screenshot "+e.getMessage());
			} 
	}
		driver.close();
		driver.quit();
	}
	
	
	
}




//Backup code 


/*
 * 
 * 		//driver.findElement(By.xpath("//div[contains(text(), 'Production')]")).click();
		//selectByVisibleText("Production");
		
		//new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"addBackendEndPointForm\"]/div[3]/div[2]/div[2]"))).click().build().perform();
		
		/*
		WebElement select = driver.findElement(By.className("item"));
		List<WebElement> lists = select.findElements(By.tagName("Production"));
		for (WebElement option : lists) {
		   if("Production".equals(option.getText()))
		       option.click();   
		}


		//Validation
		//Assert.assertTrue(driver.getTitle().contains("DM APIM - Publisher Portal"), "Invalid User!");
		//Assert.assertNotNull(driver.findElement(By.id("profileImage")));
		/*
		if(TestType.equalsIgnoreCase("P")){
			Assert.assertEquals(driver.getCurrentUrl(), Expected);
		}
		if(TestType.equalsIgnoreCase("N")){
			Assert.assertEquals(driver.findElement(By.cssSelector("#errorBlock > div") ).getText(), Expected);
			System.out.println("Login Successful");
		}*/
		
		//driver.quit();
 

/*JavascriptExecutor Scrool = (JavascriptExecutor) driver;
Scrool.executeScript("window.scrollBy(0,300)", "");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);*/

/*
driver.findElement(By.xpath("//div[@class='ui dropdown dropdownWidth changedprodvalues backendEPSecVal sample selection upward']")).click();
Thread.sleep(1000);
driver.findElement(By.xpath("//div[@class='menu transition visible']/div[contains(text(), 'Basic Authentication')]")).click();
Thread.sleep(1000);*/





