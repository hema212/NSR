package testMod;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dmapim.testauto.utilities.SQLJDBCDriver;

public class testModule {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sourav_sen\\Desktop\\AutomateEverything!\\Selenium\\Chrome Drivers\\80.0.3987.16\\chromedriver_win32_80\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//User Details
		String username = "DemoUser1";
		String UserContact = "1236661236";
		String UserEmailID = "demo@thbs.com";
		String NewPassword = "Password123!";
		String apphost = "34.227.233.177";//objectRepo.getProperty("apphost");
		
		//login to pub portal
		driver.get("http://34.227.233.177/dmapim/publisher/login.html?publisherName=four");
		//http://15.206.44.116/dmapim/publisher/login.html?publisherName=smitha
		//http://34.227.233.177/dmapim/pubportal/four
		driver.findElement(By.id("otherLoginOptions")).click();
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("/html/body/div[2]/div[1]/a"))).click().build().perform();
		driver.findElement(By.xpath("//*[@id=\"username_view\"]")).sendKeys(username);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/center/div/div/div[4]/div[1]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"closeModal\"]")).click();
		//driver.close();
		
		String ResetURL = null;
		try {
			ResetURL = SQLJDBCDriver.getDB("jdbc:mysql://3.217.111.247:3306/NSR4FALSE", "root", "Thbs123!", apphost, "four", "pub");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Redirecting to... "+ResetURL);
		Thread.sleep(2000);
		driver.get(ResetURL);
		
		driver.findElement(By.cssSelector("#username_view")).sendKeys(username);
		//driver.findElement(By.id("contact_number")).sendKeys(UserContact);		//for 34 machine
		driver.findElement(By.cssSelector("#email_id")).sendKeys(UserEmailID);
		driver.findElement(By.cssSelector("#newPassword")).sendKeys("Password123!");
		driver.findElement(By.cssSelector("#confirmPassword")).sendKeys("Password123!");		
		driver.findElement(By.cssSelector("#loginbutton")).click();
		
		Thread.sleep(5000);
		
		boolean invalidpwdheader = driver.findElement(By.cssSelector("#errorBlock > div")).getText().contains("Please enter valid inputs");
		if(!invalidpwdheader == true)
		{
		//validate login with new credential
		driver.findElement(By.id("username_view")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(NewPassword);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/center/form/div/div[4]/div/button")).click();
		Thread.sleep(10000);}
        driver.quit();
	}

}
